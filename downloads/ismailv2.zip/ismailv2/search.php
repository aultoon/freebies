<?php get_header(); ?>

<!-- Main container -->
<div class="page-container">
    <!-- bloc-0 -->
    <?php get_template_part( 'templates/home', 'header' ); ?>
    <!-- bloc-0 END -->
    <!-- bloc-0 -->
    <?php get_template_part( 'templates/home', 'wellcome' ); ?>
    <!-- bloc-0 END -->
    <!-- bloc-3 -->
    <div class="bloc l-bloc" id="bloc-3">
        <div class="container bloc-sm bloc-sm-lg">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <h1 class="mg-md ubuntu-mono"> <?php _e( 'Arama yap', 'ismail' ); ?> </h1>
                    <?php get_search_form( true ); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-3 END -->
    <!-- bloc-3 -->
    <div class="bloc l-bloc" id="bloc-3">
        <div class="container bloc-no-padding-lg bloc-no-padding">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <h1 class="mg-md ubuntu-mono"> <?php _e( 'Sonuçlar', 'ismail' ); ?> </h1>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-3 END -->
    <!-- bloc-3 -->
    <div class="bloc l-bloc" id="bloc-3">
        <div class="container bloc-sm-lg bloc-sm">
            <?php rewind_posts(); ?>
            <?php if ( have_posts() ) : ?>
                <?php $item_number = 0; ?>
                <?php while ( have_posts() ) : the_post(); ?>
                    <?php if( $item_number >= 0 && $item_number <= 4 ) : ?>
                        <?php PG_Helper::rememberShownPost(); ?>
                        <div <?php post_class( 'row' ); ?> id="post-<?php the_ID(); ?>">
                            <div class="col-md-6 col-lg-4 offset-lg-1">
                                <?php echo PG_Image::getPostImage( null, 'full', array(
                                        'class' => 'img-fluid mx-auto d-block lazyload',
                                        'data-src' => 'img/sky-clouds-trees-moon.jpg'
                                ), 'both', null ) ?>
                            </div>
                            <div class="col-md-6 offset-lg-0 col-lg-4">
                                <div class="row g-0">
                                    <div class="col-lg-5">
                                        <?php the_category( null, 'single' ); ?>
                                    </div>
                                    <div class="col-lg-7">
                                        <p class="mg-clear float-lg-none ubuntu-mono"><?php the_time( get_option( 'date_format' ) ); ?></p>
                                    </div>
                                </div>
                                <h3 class="mg-md tc-black ubuntu-mono"> <?php if ( !is_singular() ) : ?><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a><?php endif; ?> </h3>
                                <p class="ubuntu-mono"><?php echo get_the_excerpt(); ?></p>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php $item_number++; ?>
                <?php endwhile; ?>
            <?php else : ?>
                <p><?php _e( 'Sorry, no posts matched your criteria.', 'ismail' ); ?></p>
            <?php endif; ?>
        </div>
    </div>
    <!-- bloc-3 END -->
    <!-- bloc-4 -->
    <!-- bloc-4 END -->
    <!-- bloc-4 -->
    <!-- bloc-4 END -->
    <!-- bloc-5 -->
    <!-- bloc-5 END -->
    <!-- bloc-6 -->
    <!-- bloc-6 END -->
    <!-- bloc-7 -->
    <!-- bloc-7 END -->
    <!-- bloc-8 -->
    <?php get_template_part( 'templates/home', 'pagination' ); ?>
    <!-- bloc-8 END -->
    <!-- ScrollToTop Button --><a class="bloc-button btn btn-d scrollToTop" onclick="scrollToTarget('1',this)"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 32 32">
            <path class="scroll-to-top-btn-icon" d="M30,22.656l-14-13-14,13"/>
        </svg></a>
    <!-- ScrollToTop Button END-->
    <!-- bloc-4 -->
    <?php get_template_part( 'templates/home', 'footer' ); ?>
    <!-- bloc-4 END -->
</div>        

<?php get_footer(); ?>