<?php get_header(); ?>

<!-- Main container -->
<div class="page-container">
    <!-- bloc-0 -->
    <?php get_template_part( 'templates/home', 'header' ); ?>
    <!-- bloc-0 END -->
    <!-- bloc-10 -->
    <div class="bloc tc-black l-bloc" id="bloc-10">
        <div class="container bloc-sm-lg bloc-sm">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <img src="<?php echo get_template_directory_uri(); ?>/img/lazyload-ph.png" data-src="<?php echo get_stylesheet_directory_uri(); ?>/img/404.png" class="img-fluid mg-md img-style mx-auto d-block lazyload" alt="sky clouds-trees-moon"/>
                    <h1 class="fontherosecondary mg-md text-lg-center"> <?php _e( '404 Bulunamadı.', 'ismail' ); ?> </h1>
                    <p class="text-lg-center"> <?php _e( 'Aradığınız sayfa taşınmış veya hiç olmamış olabilir. Arama butonunu deneyebilir ya da anasayfayı ziyaret edebilirsiniz.', 'ismail' ); ?> </p>
                    <?php get_search_form( true ); ?>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-10 END -->
    <!-- bloc-4 -->
    <?php get_template_part( 'templates/home', 'footer' ); ?>
    <!-- bloc-4 END -->
</div>        

<?php get_footer(); ?>