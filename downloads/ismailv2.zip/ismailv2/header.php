<!doctype html>
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>"/>
        <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover"/>
        <link rel="shortcut icon" type="image/png" href="<?php echo get_template_directory_uri(); ?>/favicon.png"/>
        <link rel="preconnect" href="https://fonts.googleapis.com"/>
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
        <style>::-moz-selection { /* Code for Firefox */ background: #FFD546; } ::selection { background: #FFD546; }</style>
        <!-- Analytics -->
        <!-- Global site tag (gtag.js) - Google Analytics -->
        <!-- Analytics END -->
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>"/>
        <?php wp_head(); ?>
    </head>
    <body class="mob-disable-anim  <?php echo implode(' ', get_body_class()); ?>">
        <?php if( function_exists( 'wp_body_open' ) ) wp_body_open(); ?>