<?php get_header(); ?>

<!-- Main container -->
<div class="page-container">
    <!-- bloc-0 -->
    <?php get_template_part( 'templates/home', 'header' ); ?>
    <!-- bloc-0 END -->
    <!-- bloc-0 -->
    <?php get_template_part( 'templates/home', 'wellcome' ); ?>
    <!-- bloc-0 END -->
    <!-- bloc-3 -->
    <?php get_template_part( 'templates/sticky', 'post' ); ?>
    <!-- bloc-3 END -->
    <!-- bloc-3 -->
    <div class="bloc l-bloc" id="bloc-3">
        <div class="container bloc-no-padding-lg bloc-no-padding">
            <div class="row">
                <div class="col-lg-10 offset-lg-1">
                    <h1 class="mg-md ubuntu-mono"> <?php _e( 'Son gönderiler', 'ismail' ); ?> </h1>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-3 END -->
    <!-- bloc-3 -->
    <?php get_template_part( 'templates/latest', 'post' ); ?>
    <!-- bloc-3 END -->
    <!-- bloc-4 -->
    <!-- bloc-4 END -->
    <!-- bloc-4 -->
    <!-- bloc-4 END -->
    <!-- bloc-5 -->
    <!-- bloc-5 END -->
    <!-- bloc-6 -->
    <!-- bloc-6 END -->
    <!-- bloc-7 -->
    <!-- bloc-7 END -->
    <!-- bloc-8 -->
    <div class="bloc none l-bloc" id="bloc-8">
        <div class="container bloc-md-lg bloc-md">
            <div class="row align-items-center">
                <div class="offset-lg-5 col-lg-4 align-self-center"><a href="index.html" class="btn btn-sq btn-true-blue"><?php _e( 'Button', 'ismail' ); ?></a>
                    <a href="index.html" class="btn btn-sq btn-cornflower-blue"><?php _e( '1', 'ismail' ); ?></a>
                    <a href="index.html" class="btn btn-sq btn-true-blue"><?php _e( 'Button', 'ismail' ); ?></a>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-8 END -->
    <!-- ScrollToTop Button --><a class="bloc-button btn btn-d scrollToTop" onclick="scrollToTarget('1',this)"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 32 32">
            <path class="scroll-to-top-btn-icon" d="M30,22.656l-14-13-14,13"/>
        </svg></a>
    <!-- ScrollToTop Button END-->
    <!-- bloc-4 -->
    <?php get_template_part( 'templates/home', 'footer' ); ?>
    <!-- bloc-4 END -->
</div>        

<?php get_footer(); ?>