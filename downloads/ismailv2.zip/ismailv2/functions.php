<?php
if ( ! function_exists( 'ismail_setup' ) ) :

function ismail_setup() {

    /*
     * Make theme available for translation.
     * Translations can be filed in the /languages/ directory.
     */
    /* Aultoon generated Load Text Domain Begin */
    load_theme_textdomain( 'ismail', get_template_directory() . '/languages' );
    /* Aultoon generated Load Text Domain End */

    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );

    /*
     * Let WordPress manage the document title.
     */
    add_theme_support( 'title-tag' );
    
    /*
     * Enable support for Post Thumbnails on posts and pages.
     */
    add_theme_support( 'post-thumbnails' );
    //Support custom logo
    add_theme_support( 'custom-logo' );

    // Add menus.
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'ismail' ),
        'social'  => __( 'Social Links Menu', 'ismail' ),
    ) );

/*
     * Register custom menu locations
     */
    /* Aultoon generated Register Menus Begin */

    register_nav_menu(  'primary', __( 'Primary', 'ismail' )  );

    /* Aultoon generated Register Menus End */
    
/*
    * Set image sizes
     */
    /* Aultoon generated Image sizes Begin */

    /* Aultoon generated Image sizes End */
    
    /*
     * Switch default core markup for search form, comment form, and comments
     * to output valid HTML5.
     */
    add_theme_support( 'html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
    ) );

    /*
     * Enable support for Post Formats.
     */
    add_theme_support( 'post-formats', array(
        'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
    ) );

    /*
     * Enable support for Page excerpts.
     */
     add_post_type_support( 'page', 'excerpt' );
}
endif; // ismail_setup

add_action( 'after_setup_theme', 'ismail_setup' );


if ( ! function_exists( 'ismail_init' ) ) :

function ismail_init() {

    
    // Use categories and tags with attachments
    register_taxonomy_for_object_type( 'category', 'attachment' );
    register_taxonomy_for_object_type( 'post_tag', 'attachment' );

    /*
     * Register custom post types. You can also move this code to a plugin.
     */
    /* Aultoon generated Custom Post Types Begin */

    /* Aultoon generated Custom Post Types End */
    
    /*
     * Register custom taxonomies. You can also move this code to a plugin.
     */
    /* Aultoon generated Taxonomies Begin */

    /* Aultoon generated Taxonomies End */

}
endif; // ismail_setup

add_action( 'init', 'ismail_init' );


if ( ! function_exists( 'ismail_custom_image_sizes_names' ) ) :

function ismail_custom_image_sizes_names( $sizes ) {

    /*
     * Add names of custom image sizes.
     */
    /* Aultoon generated Image Sizes Names Begin*/
    /* This code will be replaced by returning names of custom image sizes. */
    /* Aultoon generated Image Sizes Names End */
    return $sizes;
}
add_action( 'image_size_names_choose', 'ismail_custom_image_sizes_names' );
endif;// ismail_custom_image_sizes_names



if ( ! function_exists( 'ismail_widgets_init' ) ) :

function ismail_widgets_init() {

    /*
     * Register widget areas.
     */
    /* Aultoon generated Register Sidebars Begin */

    /* Aultoon generated Register Sidebars End */
}
add_action( 'widgets_init', 'ismail_widgets_init' );
endif;// ismail_widgets_init



if ( ! function_exists( 'ismail_customize_register' ) ) :

function ismail_customize_register( $wp_customize ) {
    // Do stuff with $wp_customize, the WP_Customize_Manager object.

    /* Aultoon generated Customizer Controls Begin */

    /* Aultoon generated Customizer Controls End */

}
add_action( 'customize_register', 'ismail_customize_register' );
endif;// ismail_customize_register


if ( ! function_exists( 'ismail_enqueue_scripts' ) ) :
    function ismail_enqueue_scripts() {

        /* Aultoon generated Enqueue Scripts Begin */

    wp_deregister_script( 'ismail-script' );
    wp_enqueue_script( 'ismail-script', 'https://www.googletagmanager.com/gtag/js?id=UA-68419911-4', false, null, false);

    wp_register_script( 'inline-script-1', '', [], '', false );
    wp_enqueue_script( 'inline-script-1' );
    wp_add_inline_script( 'inline-script-1', 'window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag(\'js\', new Date());

  gtag(\'config\', \'UA-68419911-4\');');

    wp_deregister_script( 'ismail-bootstrapbundle' );
    wp_enqueue_script( 'ismail-bootstrapbundle', get_template_directory_uri() . '/./js/bootstrap.bundle.js?6906', false, null, true);

    wp_deregister_script( 'ismail-blocs' );
    wp_enqueue_script( 'ismail-blocs', get_template_directory_uri() . '/./js/blocs.min.js?5047', false, null, true);

    wp_deregister_script( 'ismail-lazysizes' );
    wp_enqueue_script( 'ismail-lazysizes', get_template_directory_uri() . '/./js/lazysizes.min.js', false, null, true);

    wp_register_script( 'inline-script-2', '', [], '', true );
    wp_enqueue_script( 'inline-script-2' );
    wp_add_inline_script( 'inline-script-2', 'var disqus_config = function (){this.page.url = \'https://www.ismailyasar.org/single.html\';this.page.identifier = PAGE_IDENTIFIER;};(function() {var d = document, s = d.createElement(\'script\');s.src = \'//i-au.disqus.com/embed.js\';s.setAttribute(\'data-timestamp\', +new Date());(d.head || d.body).appendChild(s);})();');

    /* Aultoon generated Enqueue Scripts End */

        /* Aultoon generated Enqueue Styles Begin */

    wp_deregister_style( 'ismail-bootstrap' );
    wp_enqueue_style( 'ismail-bootstrap', get_template_directory_uri() . '/./css/bootstrap.css?1417', false, null, 'all');

    wp_deregister_style( 'ismail-style' );
    wp_enqueue_style( 'ismail-style', get_template_directory_uri() . '/style.css?9525', false, null, 'all');

    wp_deregister_style( 'ismail-style-1' );
    wp_enqueue_style( 'ismail-style-1', 'https://fonts.googleapis.com/css?family=Ubuntu+Mono&display=swap&subset=latin,latin-ext', false, null, 'all');

    wp_deregister_style( 'ismail-style-2' );
    wp_enqueue_style( 'ismail-style-2', 'https://fonts.googleapis.com/css2?family=Ubuntu+Mono:ital,wght@0,400;0,700;1,400;1,700&display=swap', false, null, 'all');

    wp_deregister_style( 'ismail-style-3' );
    wp_enqueue_style( 'ismail-style-3', get_bloginfo('stylesheet_url'), false, null, 'all');

    /* Aultoon generated Enqueue Styles End */

    }
    add_action( 'wp_enqueue_scripts', 'ismail_enqueue_scripts' );
endif;

function pgwp_sanitize_placeholder($input) { return $input; }
/*
 * Resource files included by Aultoon.
 */
/* Aultoon generated Include Resources Begin */
require_once "inc/custom.php";
require_once "inc/wp_pg_helpers.php";
require_once "inc/wp_smart_navwalker.php";
require_once "inc/wp_pg_pagination.php";

    /* Aultoon generated Include Resources End */
?>