<?php get_header(); ?>

        <!-- Main container -->
        <div class="page-container">
            <!-- bloc-0 -->
            <?php get_template_part( 'templates/home', 'header' ); ?>
            <!-- bloc-0 END -->
            <!-- bloc-50 -->
            <div class="bloc l-bloc" id="bloc-50">
                <div class="container bloc-sm-lg bloc-sm">
                    <div class="row">
                        <?php if ( have_posts() ) : ?>
                            <?php while ( have_posts() ) : the_post(); ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class( 'col-lg-8 offset-lg-2' ); ?> id="post-<?php the_ID(); ?>">
                                    <?php the_category( null, 'single' ); ?>
                                    <p><?php the_time( get_option( 'date_format' ) ); ?></p>
                                    <h1 class="tc-black ubuntu-mono"><?php the_title(); ?></h1>
                                    <?php get_template_part( 'templates/share', 'buttons' ); ?>
                                    <div class="topmargin30px" onclick="#">
</div>
                                    <?php echo PG_Image::getPostImage( null, 'full', array(
                                            'class' => 'img-fluid mx-auto d-block img-rd-md lazyload',
                                            'data-src' => 'img/pexels-pixabay-276452.jpg'
                                    ), 'both', null ) ?>
                                    <?php the_content(); ?>
                                    <?php get_template_part( 'templates/share', 'buttons' ); ?>
                                    <h3 class="topmargin30px mg-md"> <?php _e( 'Yorumlar:', 'ismail' ); ?> </h3>
                                    <disqus>
                                        <div id="disqus_thread">
</div>
                                        <noscript>
                                            <?php _e( 'Please enable JavaScript to view the &amp;amp;lt;a href="https://disqus.com/?ref_noscript"&amp;amp;gt;comments powered by Disqus.&amp;amp;lt;/a&amp;amp;gt;', 'ismail' ); ?>
                                        </noscript>
                                    </disqus>
                                </div>
                            <?php endwhile; ?>
                        <?php else : ?>
                            <p><?php _e( 'Sorry, no posts matched your criteria.', 'ismail' ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- bloc-50 END -->
            <!-- bloc-51 -->
            <div class="bloc l-bloc" id="bloc-51">
                <div class="container bloc-sm-lg bloc-sm">
                    <div class="row">
                        <div class="col-lg-8 offset-lg-2">
                            <div>
                                <h3 class="mg-md tc-black uppercase"> <?php _e( 'SON YAZILAR:', 'ismail' ); ?> </h3>
                            </div>
                            <?php
                                $post_query_args = array(
                                    'post_type' => 'post',
                                    'nopaging' => true,
                                    'order' => 'ASC',
                                    'orderby' => 'date'
                                )
                            ?>
                            <?php $post_query = new WP_Query( $post_query_args ); ?>
                            <?php if ( $post_query->have_posts() ) : ?>
                                <?php $post_query_item_number = 0; ?>
                                <?php while ( $post_query->have_posts() ) : $post_query->the_post(); ?>
                                    <?php if( $post_query_item_number == 0 ) : ?>
                                        <?php PG_Helper::rememberShownPost(); ?>
                                        <div <?php post_class( 'row align-items-center box-shadow-hover' ); ?> id="post-<?php the_ID(); ?>">
                                            <div class="col-lg-3">
                                                <?php echo PG_Image::getPostImage( null, 'large', array(
                                                        'class' => 'img-fluid float-lg-none lazyload',
                                                        'data-src' => 'img/pexels-rodrigo-santos-3888149.jpg'
                                                ), 'both', null ) ?>
                                            </div>
                                            <div class="col align-self-center">
                                                <?php $terms = get_the_terms( get_the_ID(), 'category' ) ?>
                                                <?php if( !empty( $terms ) ) : ?>
                                                    <?php foreach( $terms as $term ) : ?>
                                                        <label class="uppercase mg-clear">
                                                            <?php echo $term->name; ?>
                                                        </label>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                                <h5 class="tc-black"> <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a><br/> </h5>
                                                <label class="mg-clear">
                                                    <?php the_time( get_option( 'date_format' ) ); ?>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php $post_query_item_number++; ?>
                                <?php endwhile; ?>
                                <?php wp_reset_postdata(); ?>
                            <?php else : ?>
                                <p><?php _e( 'Sorry, no posts matched your criteria.', 'ismail' ); ?></p>
                            <?php endif; ?>
                            <?php
                                $post_query_args = array(
                                    'post_type' => 'post',
                                    'nopaging' => true,
                                    'order' => 'ASC',
                                    'orderby' => 'date'
                                )
                            ?>
                            <?php $post_query = new WP_Query( $post_query_args ); ?>
                            <?php if ( $post_query->have_posts() ) : ?>
                                <?php $post_query_item_number = 0; ?>
                                <?php while ( $post_query->have_posts() ) : $post_query->the_post(); ?>
                                    <?php if( $post_query_item_number == 1 ) : ?>
                                        <?php PG_Helper::rememberShownPost(); ?>
                                        <div <?php post_class( 'row voffset align-items-center box-shadow-hover' ); ?> id="post-<?php the_ID(); ?>">
                                            <div class="col-lg-3">
                                                <?php echo PG_Image::getPostImage( null, 'large', array(
                                                        'class' => 'img-fluid float-lg-none lazyload',
                                                        'data-src' => 'img/pexels-negative-space-160107.jpg'
                                                ), 'both', null ) ?>
                                            </div>
                                            <div class="col align-self-center">
                                                <?php $terms = get_the_terms( get_the_ID(), 'category' ) ?>
                                                <?php if( !empty( $terms ) ) : ?>
                                                    <?php foreach( $terms as $term ) : ?>
                                                        <label class="mg-clear uppercase">
                                                            <?php echo $term->name; ?>
                                                        </label>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                                <h5 class="tc-black"> <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a><br/> </h5>
                                                <label class="mg-clear">
                                                    <?php _e( '26 Aug 2021', 'ismail' ); ?>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php $post_query_item_number++; ?>
                                <?php endwhile; ?>
                                <?php wp_reset_postdata(); ?>
                            <?php else : ?>
                                <p><?php _e( 'Sorry, no posts matched your criteria.', 'ismail' ); ?></p>
                            <?php endif; ?>
                            <?php
                                $post_query_args = array(
                                    'post_type' => 'post',
                                    'nopaging' => true,
                                    'order' => 'ASC',
                                    'orderby' => 'date'
                                )
                            ?>
                            <?php $post_query = new WP_Query( $post_query_args ); ?>
                            <?php if ( $post_query->have_posts() ) : ?>
                                <?php $post_query_item_number = 0; ?>
                                <?php while ( $post_query->have_posts() ) : $post_query->the_post(); ?>
                                    <?php if( $post_query_item_number == 2 ) : ?>
                                        <?php PG_Helper::rememberShownPost(); ?>
                                        <div <?php post_class( 'row voffset align-items-center box-shadow-hover' ); ?> id="post-<?php the_ID(); ?>">
                                            <div class="col-lg-3">
                                                <?php echo PG_Image::getPostImage( null, 'large', array(
                                                        'class' => 'img-fluid float-lg-none lazyload',
                                                        'data-src' => 'img/pexels-markus-spiske-177598.jpg'
                                                ), 'both', null ) ?>
                                            </div>
                                            <div class="col offset-lg-0 align-self-center">
                                                <?php $terms = get_the_terms( get_the_ID(), 'category' ) ?>
                                                <?php if( !empty( $terms ) ) : ?>
                                                    <?php foreach( $terms as $term ) : ?>
                                                        <label class="uppercase mg-clear">
                                                            <?php echo $term->name; ?>
                                                        </label>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                                <h5 class="tc-black"> <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a><br/> </h5>
                                                <label class="mg-clear">
                                                    <?php the_time( get_option( 'date_format' ) ); ?>
                                                </label>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                    <?php $post_query_item_number++; ?>
                                <?php endwhile; ?>
                                <?php wp_reset_postdata(); ?>
                            <?php else : ?>
                                <p><?php _e( 'Sorry, no posts matched your criteria.', 'ismail' ); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-51 END -->
            <!-- ScrollToTop Button -->
            <a class="bloc-button btn btn-d scrollToTop" onclick="scrollToTarget('1',this)"><svg xmlns="http://www.w3.org/2000/svg" width="22" height="22" viewBox="0 0 32 32">
                    <path class="scroll-to-top-btn-icon" d="M30,22.656l-14-13-14,13"/>
                </svg></a>
            <!-- ScrollToTop Button END-->
            <!-- bloc-4 -->
            <?php get_template_part( 'templates/home', 'footer' ); ?>
            <!-- bloc-4 END -->
        </div>        

<?php get_footer(); ?>