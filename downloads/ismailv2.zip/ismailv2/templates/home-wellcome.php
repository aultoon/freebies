<div class="bloc tc-medium-jungle-green l-bloc" id="bloc-0">
    <div class="container bloc-md bloc-md-lg">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <h1 class="mg-md fontherofirst"> <?php _e( 'Bloguma hoşgeldiniz.', 'ismail' ); ?> </h1>
                <h1 class="mg-md fontherosecondary"> <?php _e( 'Bir takım kişisel paylaşımlar...', 'ismail' ); ?> </h1>
                <p class="fontherop a"> <?php _e( 'Boş kaldığım vakitlerde şuraya bir kaç şey eklemeye çalışacağım. Paylaştığım şeyleri mutlak doğru kabul etmiyorum, bugün başka yarın başka düşünebilirim. Okudukça, gördükçe, yaşadıkça fikirlerimdeki değişimler gayet normal bi durum gibi sanki...', 'ismail' ); ?> </p>
            </div>
        </div>
    </div>
</div>