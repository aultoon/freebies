<div class="bloc l-bloc" id="bloc-3">
    <div class="container bloc-sm bloc-sm-lg">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <h1 class="mg-md ubuntu-mono"> <?php _e( 'Öne Çıkanlar', 'ismail' ); ?> </h1>
                <div class="row">
                    <?php
                        $post_query_args = array(
                            'post__in' => get_option( 'sticky_posts' ),
                            'post_type' => 'post',
                            'nopaging' => true,
                            'ignore_sticky_posts' => true,
                            'order' => 'ASC',
                            'orderby' => 'date'
                        )
                    ?>
                    <?php $post_query = new WP_Query( $post_query_args ); ?>
                    <?php if ( $post_query->have_posts() ) : ?>
                        <?php $post_query_item_number = 0; ?>
                        <?php while ( $post_query->have_posts() ) : $post_query->the_post(); ?>
                            <?php if( $post_query_item_number == 0 ) : ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class( 'col-12 col-lg-4 box-shadow-hover' ); ?> id="post-<?php the_ID(); ?>">
                                    <div class="row">
                                        <div class="col-12 margin5 col-lg-6">
                                            <?php echo PG_Image::getPostImage( null, 'full', array(
                                                    'class' => 'img-fluid mx-auto d-block rounded lazyload',
                                                    'data-src' => 'img/sky-clouds-trees-moon.jpg'
                                            ), 'both', null ) ?>
                                        </div>
                                        <div class="col margin5">
                                            <?php if ( !is_singular() ) : ?>
                                                <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a>
                                            <?php endif; ?>
                                            <p class="mg-sm"><?php the_time( get_option( 'date_format' ) ); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php $post_query_item_number++; ?>
                        <?php endwhile; ?>
                        <?php wp_reset_postdata(); ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'ismail' ); ?></p>
                    <?php endif; ?>
                    <?php
                        $post_query_args = array(
                            'post__in' => get_option( 'sticky_posts' ),
                            'post_type' => 'post',
                            'nopaging' => true,
                            'ignore_sticky_posts' => true,
                            'order' => 'ASC',
                            'orderby' => 'date'
                        )
                    ?>
                    <?php $post_query = new WP_Query( $post_query_args ); ?>
                    <?php if ( $post_query->have_posts() ) : ?>
                        <?php $post_query_item_number = 0; ?>
                        <?php while ( $post_query->have_posts() ) : $post_query->the_post(); ?>
                            <?php if( $post_query_item_number == 1 ) : ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class( 'col-12 col-lg-4 box-shadow-hover' ); ?> id="post-<?php the_ID(); ?>">
                                    <div class="row">
                                        <div class="col-12 margin5 col-lg-6">
                                            <?php echo PG_Image::getPostImage( null, 'full', array(
                                                    'class' => 'img-fluid mx-auto d-block rounded lazyload',
                                                    'data-src' => 'img/sky-clouds-trees-moon.jpg'
                                            ), 'both', null ) ?>
                                        </div>
                                        <div class="col margin5">
                                            <?php if ( !is_singular() ) : ?>
                                                <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a>
                                            <?php endif; ?>
                                            <p class="mg-sm"><?php the_time( get_option( 'date_format' ) ); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php $post_query_item_number++; ?>
                        <?php endwhile; ?>
                        <?php wp_reset_postdata(); ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'ismail' ); ?></p>
                    <?php endif; ?>
                    <?php
                        $post_query_args = array(
                            'post__in' => get_option( 'sticky_posts' ),
                            'post_type' => 'post',
                            'nopaging' => true,
                            'ignore_sticky_posts' => true,
                            'order' => 'ASC',
                            'orderby' => 'date'
                        )
                    ?>
                    <?php $post_query = new WP_Query( $post_query_args ); ?>
                    <?php if ( $post_query->have_posts() ) : ?>
                        <?php $post_query_item_number = 0; ?>
                        <?php while ( $post_query->have_posts() ) : $post_query->the_post(); ?>
                            <?php if( $post_query_item_number == 2 ) : ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class( 'col-12 col-lg-4 box-shadow-hover' ); ?> id="post-<?php the_ID(); ?>">
                                    <div class="row">
                                        <div class="col-12 margin5 col-lg-6">
                                            <?php echo PG_Image::getPostImage( null, 'full', array(
                                                    'class' => 'img-fluid mx-auto d-block rounded lazyload',
                                                    'data-src' => 'img/sky-clouds-trees-moon.jpg'
                                            ), 'both', null ) ?>
                                        </div>
                                        <div class="col margin5">
                                            <?php if ( !is_singular() ) : ?>
                                                <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a>
                                            <?php endif; ?>
                                            <p class="mg-sm"><?php the_time( get_option( 'date_format' ) ); ?></p>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                            <?php $post_query_item_number++; ?>
                        <?php endwhile; ?>
                        <?php wp_reset_postdata(); ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'ismail' ); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div>