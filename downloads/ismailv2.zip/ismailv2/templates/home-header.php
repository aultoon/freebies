<div class="bloc l-bloc" id="bloc-0">
    <div class="container bloc-sm">
        <div class="row">
            <div class="col-lg-10 offset-lg-1">
                <nav class="navbar navbar-light row navbar-expand-md" role="navigation">
                    <div class="container-fluid">
                        <a class="navbar-brand" href="<?php echo esc_url( home_url() ); ?>"><?php _e( 'ismail\'s blog', 'ismail' ); ?></a>
                        <button id="nav-toggle" type="button" class="ui-navbar-toggler navbar-toggler border-0 p-0 ms-auto" aria-expanded="false" aria-label="Toggle navigation" data-bs-toggle="collapse" data-bs-target=".navbar-13003">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse navbar-13003">
                            <?php if ( has_nav_menu( 'primary' ) ) : ?>
                                <?php
                                    PG_Smart_Walker_Nav_Menu::$options['template'] = '<li class="nav-item {CLASSES}" id="{ID}"><a class="nav-link a-btn" {ATTRS}>{TITLE}</a>
                                                                                </li>';
                                    wp_nav_menu( array(
                                        'container' => '',
                                        'theme_location' => 'primary',
                                        'items_wrap' => '<ul class="%2$s ms-auto nav navbar-nav site-navigation" id="%1$s">%3$s</ul>',
                                        'walker' => new PG_Smart_Walker_Nav_Menu()
                                ) ); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</div>