<div id="bloc-3" <?php post_class( 'bloc l-bloc' ); ?>>
    <div class="container bloc-sm-lg bloc-sm">
        <div class="row">
            <div class="col-md-6 col-lg-4 offset-lg-1">
                <?php echo PG_Image::getPostImage( null, 'large', array(
                        'class' => 'img-fluid mx-auto d-block lazyload',
                        'data-src' => 'img/sky-clouds-trees-moon.jpg'
                ), 'both', null ) ?>
            </div>
            <div class="col-md-6 offset-lg-0 col-lg-4">
                <div class="row g-0">
                    <div class="col-lg-5">
                        <?php the_category( null, 'single' ); ?>
                    </div>
                    <div class="col-lg-7">
                        <p class="mg-clear float-lg-none" style="text-transform: uppercase;"><?php echo human_time_diff(get_the_time('U'),current_time('timestamp')).' ÖNCE'; ?></p>
                    </div>
                </div>
                <h3 class="mg-md tc-black ubuntu-mono"> <a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a> </h3>
                <p class="ubuntu-mono"><?php echo get_the_excerpt(); ?></p>
            </div>
        </div>
    </div>
</div>