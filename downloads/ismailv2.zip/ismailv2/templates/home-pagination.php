<div class="bloc none l-bloc" id="bloc-8">
    <div class="container bloc-md-lg bloc-md">
        <div class="row align-items-center">
            <?php if ( PG_Pagination::isPaginated() ) : ?>
                <div class="offset-lg-5 col-lg-4 align-self-center">
                    <?php if( PG_Pagination::getCurrentPage() < PG_Pagination::getMaxPages() ) : ?>
                        <a class="btn btn-sq btn-true-blue" <?php echo PG_Pagination::getNextHrefAttribute(); ?>>&lt;&lt;</a>
                    <?php endif; ?><a href="index.html" class="btn btn-sq btn-cornflower-blue"><?php echo PG_Pagination::getCurrentPage(); ?></a>
                    <?php if( PG_Pagination::getCurrentPage() > 1 ) : ?>
                        <a class="btn btn-sq btn-true-blue" <?php echo PG_Pagination::getPreviousHrefAttribute(); ?>>&gt;&gt;</a>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>