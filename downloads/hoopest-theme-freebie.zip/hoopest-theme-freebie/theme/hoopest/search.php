<?php get_header(); ?>

<!-- Main container -->
<div class="page-container">
    <!-- bloc-0 -->
    <?php get_template_part( 'parts/main', 'header' ); ?>
    <!-- bloc-0 END -->
    <!-- bloc-19 -->
    <?php get_template_part( 'parts/main', 'slogan' ); ?>
    <!-- bloc-19 END -->
    <!-- bloc-13 -->
    <div class="bloc l-bloc" id="bloc-13">
        <div class="container bloc-lg">
            <div class="row">
                <div class="col">
                    <div class="form-group">
                        <div class="text-center">
                            <?php get_search_form( true ); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-13 END -->
    <!-- bloc-20 -->
    <div class="bloc tc-olive-drab-7 l-bloc" id="bloc-20">
        <div class="container bloc-sm">
            <div class="row">
                <?php rewind_posts(); ?>
                <?php if ( have_posts() ) : ?>
                    <?php $item_number = 0; ?>
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php if( $item_number == 0 ) : ?>
                            <?php PG_Helper::rememberShownPost(); ?>
                            <div <?php post_class( 'col-md-6 col-lg-6' ); ?> id="post-<?php the_ID(); ?>">
                                <?php if ( is_singular() ) : ?>
                                    <?php echo PG_Image::getPostImage( null, 'large', array(
                                            'class' => 'img-fluid mx-auto d-block lazyload',
                                            'data-src' => 'img/2.jpg'
                                    ), 'both', null ) ?>
                                <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                    <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'large', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/2.jpg'
                                        ), 'both', null ) ?></a>
                                <?php endif; ?>
                                <?php if ( is_singular() ) : ?>
                                    <h3 class="mg-md tc-black"><?php the_title(); ?></h3>
                                <?php else : ?>
                                    <h3 class="mg-md tc-black"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h3>
                                <?php endif; ?>
                                <p class="p-style"><?php echo get_the_excerpt(); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php $item_number++; ?>
                    <?php endwhile; ?>
                <?php else : ?>
                    <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                <?php endif; ?>
                <div class="col-lg-5 offset-lg-1">
                    <?php if ( is_active_sidebar( 'hoopsearchsidebar' ) ) : ?>
                        <?php dynamic_sidebar( 'hoopsearchsidebar' ); ?>
                    <?php endif; ?>
                </div>
            </div>
            <div class="row">
                <?php rewind_posts(); ?>
                <?php if ( have_posts() ) : ?>
                    <?php $item_number = 0; ?>
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php if( $item_number == 1 ) : ?>
                            <?php PG_Helper::rememberShownPost(); ?>
                            <div <?php post_class( 'col-md-6 col-lg-6' ); ?> id="post-<?php the_ID(); ?>">
                                <?php if ( is_singular() ) : ?>
                                    <?php echo PG_Image::getPostImage( null, 'large', array(
                                            'class' => 'img-fluid mx-auto d-block lazyload',
                                            'data-src' => 'img/2.jpg'
                                    ), 'both', null ) ?>
                                <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                    <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'large', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/2.jpg'
                                        ), 'both', null ) ?></a>
                                <?php endif; ?>
                                <?php if ( is_singular() ) : ?>
                                    <h3 class="mg-md tc-black"><?php the_title(); ?></h3>
                                <?php else : ?>
                                    <h3 class="mg-md tc-black"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h3>
                                <?php endif; ?>
                                <p class="p-style"><?php echo get_the_excerpt(); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php $item_number++; ?>
                    <?php endwhile; ?>
                <?php else : ?>
                    <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                <?php endif; ?>
            </div>
            <div class="row">
                <?php rewind_posts(); ?>
                <?php if ( have_posts() ) : ?>
                    <?php $item_number = 0; ?>
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php if( $item_number == 2 ) : ?>
                            <?php PG_Helper::rememberShownPost(); ?>
                            <div <?php post_class( 'col-md-6 col-lg-6' ); ?> id="post-<?php the_ID(); ?>">
                                <?php if ( is_singular() ) : ?>
                                    <?php echo PG_Image::getPostImage( null, 'large', array(
                                            'class' => 'img-fluid mx-auto d-block lazyload',
                                            'data-src' => 'img/2.jpg'
                                    ), 'both', null ) ?>
                                <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                    <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'large', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/2.jpg'
                                        ), 'both', null ) ?></a>
                                <?php endif; ?>
                                <?php if ( is_singular() ) : ?>
                                    <h3 class="mg-md tc-black"><?php the_title(); ?></h3>
                                <?php else : ?>
                                    <h3 class="mg-md tc-black"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h3>
                                <?php endif; ?>
                                <p class="p-style"><?php echo get_the_excerpt(); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php $item_number++; ?>
                    <?php endwhile; ?>
                <?php else : ?>
                    <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- bloc-20 END -->
    <!-- bloc-23 -->
    <div class="bloc l-bloc" id="bloc-23">
        <div class="container bloc-lg">
            <div class="row">
                <div class="col">
                    <?php if ( PG_Pagination::isPaginated() ) : ?>
                        <?php for( $page_num = 1; $page_num <= PG_Pagination::getMaxPages(); $page_num++) : ?>
                            <a href="<?php echo esc_url( get_pagenum_link( $page_num ) ) ?>" class="btn btn-yellow-orange"><?php echo $page_num ?></a>
                        <?php endfor; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-23 END -->
    <!-- ScrollToTop Button -->
    <a class="bloc-button btn btn-d scrollToTop" onclick="scrollToTarget('1',this)"><span class="fa fa-chevron-up"></span></a>
    <!-- ScrollToTop Button END-->
    <!-- bloc-41 -->
    <?php get_template_part( 'parts/main', 'footer' ); ?>
    <!-- bloc-41 END -->
</div>        

<?php get_footer(); ?>