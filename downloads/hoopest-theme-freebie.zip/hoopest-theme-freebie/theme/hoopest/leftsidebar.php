<?php
/*
 Template Name: Page with left sidebar
 Template Post Type: post, page
*/
?>
<?php get_header(); ?>

        <!-- Main container -->
        <div class="page-container">
            <!-- bloc-0 -->
            <?php get_template_part( 'parts/main', 'header' ); ?>
            <!-- bloc-0 END -->
            <!-- bloc-29 -->
            <div class="bloc l-bloc" id="bloc-29">
                <div class="container bloc-lg">
                    <div class="row">
                        <div class="col">
                            <h1 class="h1-style mg-sm tc-black text-lg-center text-w-80 mx-auto d-block"><?php the_title(); ?></h1>
                            <p class="text-lg-center text-center"><?php the_time( get_option( 'date_format' ) ); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-29 END -->
            <!-- bloc-30 -->
            <div class="bloc tc-olive-drab-7 l-bloc" id="bloc-30">
                <div class="container bloc-sm">
                    <div class="row">
                        <div class="col-md-6 col-lg-12">
                            <?php echo PG_Image::getPostImage( null, 'full', array(
                                    'class' => 'img-fluid mx-auto d-block img-bloc-1-style lazyload',
                                    'data-src' => 'img/2.jpg'
                            ), 'both', null ) ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-30 END -->
            <!-- bloc-31 -->
            <div class="bloc tc-black l-bloc" id="bloc-31">
                <div class="container bloc-lg">
                    <div class="row">
                        <?php if ( is_active_sidebar( 'hooppagesidebar' ) ) : ?>
                            <div class="order-lg-0 col-lg-3">
                                <?php dynamic_sidebar( 'hooppagesidebar' ); ?>
                            </div>
                        <?php endif; ?>
                        <?php if ( have_posts() ) : ?>
                            <?php while ( have_posts() ) : the_post(); ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class( 'order-lg-0 offset-lg-0 col-lg-8' ); ?> id="post-<?php the_ID(); ?>">
                                    <?php the_content(); ?>
                                </div>
                            <?php endwhile; ?>
                        <?php else : ?>
                            <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- bloc-31 END -->
            <!-- bloc-23 -->
            <div class="bloc l-bloc" id="bloc-23">
                <div class="container bloc-lg">
                    <div class="row">
                        <div class="col">
                            <div>
                                <div class="text-center">
                                    <div class="row voffset">
                                        <div class="col">
                                            <div class="text-center">
</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-23 END -->
            <!-- bloc-32 -->
            <?php get_template_part( 'parts/main', 'authors' ); ?>
            <!-- bloc-32 END -->
            <!-- bloc-33 -->
            <div class="bloc none l-bloc" id="bloc-33">
                <div class="container bloc-md">
</div>
            </div>
            <!-- bloc-33 END -->
            <!-- ScrollToTop Button -->
            <a class="bloc-button btn btn-d scrollToTop" onclick="scrollToTarget('1',this)"><span class="fa fa-chevron-up"></span></a>
            <!-- ScrollToTop Button END-->
            <!-- bloc-41 -->
            <?php get_template_part( 'parts/main', 'footer' ); ?>
            <!-- bloc-41 END -->
        </div>        

<?php get_footer(); ?>