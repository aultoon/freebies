=== Hoopest ===
Contributors: Aultoon
Tested up to: 5.5
Stable tag: 1.5
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html


== Description ==

Simple Clean Blog Theme for Wordpress. Developed by Aultoon Inc with love and desire. Simplicity is our first purpose.

== Changelog ==

= 1.0 =
* Released first version on 2020

https://preview.aultoon.com/hoopest/

== Copyright ==

Hoopest Theme, Copyright 2020
Twenty Twenty is distributed under the terms of the GNU GPL.
