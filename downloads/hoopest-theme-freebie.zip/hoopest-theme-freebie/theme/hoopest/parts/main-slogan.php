<div class="bloc l-bloc" id="bloc-1">
    <div class="container bloc-lg">
        <div class="row">
            <div class="col">
                <h1 class="h1-style mg-sm tc-black"><?php echo get_theme_mod( 'hooptitle', __( 'Bir takım kendine has paylaşımlar. İçimi döktüğüm yer!', 'hoopest' ) ); ?></h1>
            </div>
        </div>
    </div>
</div>