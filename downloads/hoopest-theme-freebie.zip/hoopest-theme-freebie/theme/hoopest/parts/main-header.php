<div class="bloc l-bloc" id="bloc-0">
    <div class="container bloc-sm">
        <div class="row">
            <div class="col">
                <nav class="navbar navbar-light row navbar-expand-md" role="navigation">
                    <a class="navbar-brand" href="<?php echo esc_url( home_url() ); ?>"><img src="<?php echo PG_Image::getUrl( get_theme_mod( 'hoopestsettings_sitelogo', esc_url( get_template_directory_uri() . '/img/logo.png' ) ), 'large' ) ?>" alt="logo"/></a>
                    <button id="nav-toggle" type="button" class="ml-auto ui-navbar-toggler navbar-toggler border-0 p-0" data-toggle="collapse" data-target=".navbar-27203" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse navbar-27203">
                        <?php
                            PG_Smart_Walker_Nav_Menu::$options['template'] = '<li class="nav-item {CLASSES}" id="{ID}">
                            								<a class="nav-link a-btn ltc-yellow-orange" {ATTRS}>{TITLE}</a>
                            							</li>';
                            wp_nav_menu( array(
                                'menu' => 'primary',
                                'container' => '',
                                'items_wrap' => '<ul class="%2$s menu ml-auto nav navbar-nav site-navigation" id="%1$s">%3$s</ul>',
                                'walker' => new PG_Smart_Walker_Nav_Menu()
                        ) ); ?>
                    </div>
                </nav>
            </div>
        </div>
    </div>
</div>