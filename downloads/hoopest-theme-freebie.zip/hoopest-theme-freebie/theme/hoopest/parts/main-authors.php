<div class="bloc none tc-black" id="bloc-16">
    <div class="container bloc-lg">
        <div class="row">
            <div class="col-lg-2 offset-lg-1 align-self-center">
                <?php echo get_avatar( get_the_author_meta( 'ID' ), '100', null, __( 'author', 'hoopest' ) ); ?>
            </div>
            <div class="align-self-center col-lg-7">
                <h5 class="mg-sm tc-black"><?php echo get_the_author_meta( 'display_name', false ) ?></h5>
                <div>
                    <?php get_template_part( 'parts/main-author-links' ); ?>
                </div>
                <p class="author-text"><?php the_author_meta( 'user_description' ); ?></p>
            </div>
        </div>
    </div>
</div>