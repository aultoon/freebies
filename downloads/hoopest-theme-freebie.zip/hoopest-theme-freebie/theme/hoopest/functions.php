<?php
if ( ! function_exists( 'hoopest_setup' ) ) :

function hoopest_setup() {

    /*
     * Make theme available for translation.
     * Translations can be filed in the /languages/ directory.
     */
    /* Hoopest generated Load Text Domain Begin */
    load_theme_textdomain( 'hoopest', get_template_directory() . '/languages' );
    /* Hoopest generated Load Text Domain End */

    // Add default posts and comments RSS feed links to head.
    add_theme_support( 'automatic-feed-links' );

    /*
     * Let WordPress manage the document title.
     */
    add_theme_support( 'title-tag' );
    
    /*
     * Enable support for Post Thumbnails on posts and pages.
     */
    add_theme_support( 'post-thumbnails' );
    set_post_thumbnail_size( 825, 510, true );

    // Add menus.
    register_nav_menus( array(
        'primary' => __( 'Primary Menu', 'hoopest' ),
        'social'  => __( 'Social Links Menu', 'hoopest' ),
    ) );

/*
     * Register custom menu locations
     */
    /* Hoopest generated Register Menus Begin */

    /* Hoopest generated Register Menus End */
    
/*
    * Set image sizes
     */
    /* Hoopest generated Image sizes Begin */

    /* Hoopest generated Image sizes End */
    
    /*
     * Switch default core markup for search form, comment form, and comments
     * to output valid HTML5.
     */
    add_theme_support( 'html5', array(
        'search-form', 'comment-form', 'comment-list', 'gallery', 'caption'
    ) );

    /*
     * Enable support for Post Formats.
     */
    add_theme_support( 'post-formats', array(
        'aside', 'image', 'video', 'quote', 'link', 'gallery', 'status', 'audio', 'chat'
    ) );

    /*
     * Enable support for Page excerpts.
     */
     add_post_type_support( 'page', 'excerpt' );
}
endif; // hoopest_setup

add_action( 'after_setup_theme', 'hoopest_setup' );


if ( ! function_exists( 'hoopest_init' ) ) :

function hoopest_init() {

    
    // Use categories and tags with attachments
    register_taxonomy_for_object_type( 'category', 'attachment' );
    register_taxonomy_for_object_type( 'post_tag', 'attachment' );

    /*
     * Register custom post types. You can also move this code to a plugin.
     */
    /* Hoopest generated Custom Post Types Begin */

    /* Hoopest generated Custom Post Types End */
    
    /*
     * Register custom taxonomies. You can also move this code to a plugin.
     */
    /* Hoopest generated Taxonomies Begin */

    /* Hoopest generated Taxonomies End */

}
endif; // hoopest_setup

add_action( 'init', 'hoopest_init' );


if ( ! function_exists( 'hoopest_custom_image_sizes_names' ) ) :

function hoopest_custom_image_sizes_names( $sizes ) {

    /*
     * Add names of custom image sizes.
     */
    /* Hoopest generated Image Sizes Names Begin*/
    /* This code will be replaced by returning names of custom image sizes. */
    /* Hoopest generated Image Sizes Names End */
    return $sizes;
}
add_action( 'image_size_names_choose', 'hoopest_custom_image_sizes_names' );
endif;// hoopest_custom_image_sizes_names



if ( ! function_exists( 'hoopest_widgets_init' ) ) :

function hoopest_widgets_init() {

    /*
     * Register widget areas.
     */
    /* Hoopest generated Register Sidebars Begin */

    register_sidebar( array(
        'name' => __( 'Archive Sidebar', 'hoopest' ),
        'id' => 'hoopsidebararchive',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
    ) );

    register_sidebar( array(
        'name' => __( 'Homepage Sidebar', 'hoopest' ),
        'id' => 'hoopsidebar',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
    ) );

    register_sidebar( array(
        'name' => __( 'Page Sidebar', 'hoopest' ),
        'id' => 'hooppagesidebar',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
    ) );

    register_sidebar( array(
        'name' => __( 'Search Page Sidebar', 'hoopest' ),
        'id' => 'hoopsearchsidebar',
        'before_widget' => '<div id="%1$s" class="widget %2$s">',
        'after_widget' => '</div>',
        'before_title' => '<h3 class="widgettitle">',
        'after_title' => '</h3>'
    ) );

    /* Hoopest generated Register Sidebars End */
}
add_action( 'widgets_init', 'hoopest_widgets_init' );
endif;// hoopest_widgets_init



if ( ! function_exists( 'hoopest_customize_register' ) ) :

function hoopest_customize_register( $wp_customize ) {
    // Do stuff with $wp_customize, the WP_Customize_Manager object.

    /* Hoopest generated Customizer Controls Begin */

    $wp_customize->add_section( 'hoopestsettings', array(
        'title' => __( 'Hoopest Settings', 'hoopest' )
    ));
    $pgwp_sanitize = function_exists('pgwp_sanitize_placeholder') ? 'pgwp_sanitize_placeholder' : null;

    $wp_customize->add_setting( 'hoop_404_htext', array(
        'type' => 'theme_mod',
        'default' => __( '404 Not Found.', 'hoopest' ),
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_404_htext', array(
        'label' => __( '404 Page Header Text', 'hoopest' ),
        'type' => 'text',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoop_404_ptext', array(
        'type' => 'theme_mod',
        'default' => 'The page you are looking for was moved, removed, renamed or might never existed. <br>Please try searching it!',
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_404_ptext', array(
        'label' => __( '404 Page Description Text', 'hoopest' ),
        'type' => 'text',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoopestsettings_sitelogo', array(
        'type' => 'theme_mod',
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( new WP_Customize_Media_Control( $wp_customize, 'hoopestsettings_sitelogo', array(
        'label' => __( 'Site Logo', 'hoopest' ),
        'type' => 'media',
        'mime_type' => 'image',
        'section' => 'hoopestsettings'
    ) ) );

    $wp_customize->add_setting( 'hooptitle', array(
        'type' => 'theme_mod',
        'default' => __( 'Bir takım kendine has paylaşımlar. İçimi döktüğüm yer!', 'hoopest' ),
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hooptitle', array(
        'label' => __( 'Homepage Title', 'hoopest' ),
        'type' => 'textarea',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoop_foot_copy', array(
        'type' => 'theme_mod',
        'default' => 'Copyright © 2020 aultoon.com<br>',
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_foot_copy', array(
        'label' => __( 'Left Footer Text', 'hoopest' ),
        'type' => 'textarea',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoop_foot_tw', array(
        'type' => 'theme_mod',
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_foot_tw', array(
        'label' => __( 'Footer Twitter', 'hoopest' ),
        'type' => 'url',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoop_foot_fb', array(
        'type' => 'theme_mod',
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_foot_fb', array(
        'label' => __( 'Footer Facebook', 'hoopest' ),
        'type' => 'url',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoop_foot_ins', array(
        'type' => 'theme_mod',
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_foot_ins', array(
        'label' => __( 'Footer Instagram', 'hoopest' ),
        'type' => 'url',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoop_foot_right', array(
        'type' => 'theme_mod',
        'default' => __( 'Site düzeni by: Aultoon inc.', 'hoopest' ),
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_foot_right', array(
        'label' => __( 'Right Footer Text', 'hoopest' ),
        'type' => 'textarea',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoop_author_tw', array(
        'type' => 'theme_mod',
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_author_tw', array(
        'label' => __( 'Author Twitter Link', 'hoopest' ),
        'type' => 'url',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoop_author_fb', array(
        'type' => 'theme_mod',
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_author_fb', array(
        'label' => __( 'Author Facebook Link', 'hoopest' ),
        'type' => 'url',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoop_author_insta', array(
        'type' => 'theme_mod',
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_author_insta', array(
        'label' => __( 'Author Instagram Link', 'hoopest' ),
        'type' => 'url',
        'section' => 'hoopestsettings'
    ));

    $wp_customize->add_setting( 'hoop_comment_title', array(
        'type' => 'theme_mod',
        'default' => __( 'Comments:', 'hoopest' ),
        'sanitize_callback' => $pgwp_sanitize
    ));

    $wp_customize->add_control( 'hoop_comment_title', array(
        'label' => __( 'Comments Text', 'hoopest' ),
        'type' => 'textarea',
        'section' => 'hoopestsettings'
    ));

    /* Hoopest generated Customizer Controls End */

}
add_action( 'customize_register', 'hoopest_customize_register' );
endif;// hoopest_customize_register


if ( ! function_exists( 'hoopest_enqueue_scripts' ) ) :
    function hoopest_enqueue_scripts() {

        /* Hoopest generated Enqueue Scripts Begin */

    wp_deregister_script( 'jquery' );
    wp_enqueue_script( 'jquery', get_template_directory_uri() . '/./js/jquery-3.5.1.min.js?3835', false, null, true);

    wp_deregister_script( 'bootstrapbundle' );
    wp_enqueue_script( 'bootstrapbundle', get_template_directory_uri() . '/./js/bootstrap.bundle.min.js?5932', false, null, true);

    wp_deregister_script( 'blocs' );
    wp_enqueue_script( 'blocs', get_template_directory_uri() . '/./js/blocs.min.js?2737', false, null, true);

    wp_deregister_script( 'lazysizes' );
    wp_enqueue_script( 'lazysizes', get_template_directory_uri() . '/./js/lazysizes.min.js', false, null, true);

    /* Hoopest generated Enqueue Scripts End */

        /* Hoopest generated Enqueue Styles Begin */

    wp_deregister_style( 'bootstrap' );
    wp_enqueue_style( 'bootstrap', get_template_directory_uri() . '/./css/bootstrap.min.css?6828', false, null, 'all');

    wp_deregister_style( 'style' );
    wp_enqueue_style( 'style', get_template_directory_uri() . '/style.css?7205', false, null, 'all');

    wp_deregister_style( 'fontawesome' );
    wp_enqueue_style( 'fontawesome', get_template_directory_uri() . '/./css/font-awesome.min.css', false, null, 'all');

    wp_deregister_style( 'style-1' );
    wp_enqueue_style( 'style-1', 'https://fonts.googleapis.com/css?family=Montserrat:200,300,400,500,600,700,800,900&display=swap&subset=latin,latin-ext', false, null, 'all');

    wp_deregister_style( 'style-1' );
    wp_enqueue_style( 'style-1', get_bloginfo('stylesheet_url'), false, null, 'all');

    /* Hoopest generated Enqueue Styles End */

    }
    add_action( 'wp_enqueue_scripts', 'hoopest_enqueue_scripts' );
endif;

function pgwp_sanitize_placeholder($input) { return $input; }
/*
 * Resource files included by Hoopest.
 */
/* Hoopest generated Include Resources Begin */
require_once "inc/wp_pg_helpers.php";
require_once "inc/wp_pg_pagination.php";
require_once "inc/wp_smart_navwalker.php";

    /* Hoopest generated Include Resources End */
?>