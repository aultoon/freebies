<!doctype html>
<!--  HOOPEST!  -->
<html <?php language_attributes(); ?>>
    <head>
        <meta charset="<?php bloginfo( 'charset' ); ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0, viewport-fit=cover">

        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Montserrat&family=Roboto&family=Ubuntu&display=swap" rel="stylesheet">

        <!-- Analytics -->
        <!-- Analytics END -->
        <link rel="pingback" href="<?php bloginfo( 'pingback_url' ); ?>">
        <meta content="Simple Clean Blog Theme for Wordpress." name="generator">
        <?php wp_head(); ?>
    </head>
    <body class="<?php echo implode(' ', get_body_class()); ?>">
        <?php if( function_exists( 'wp_body_open' ) ) wp_body_open(); ?>