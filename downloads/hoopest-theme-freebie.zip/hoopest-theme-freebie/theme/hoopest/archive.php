<?php get_header(); ?>

<!-- Main container -->
<div class="page-container">
    <!-- bloc-0 -->
    <?php get_template_part( 'parts/main', 'header' ); ?>
    <!-- bloc-0 END -->
    <!-- bloc-0 -->
    <?php get_template_part( 'parts/main', 'slogan' ); ?>
    <!-- bloc-0 END -->
    <!-- bloc-2 -->
    <div class="bloc none l-bloc" id="bloc-2">
        <div class="container bloc-lg">
            <div class="row">
                <div class="col">
                    <?php rewind_posts(); ?>
                    <?php if ( have_posts() ) : ?>
                        <?php $item_number = 0; ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php if( $item_number == 0 ) : ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
                                    <?php if ( is_singular() ) : ?>
                                        <?php echo PG_Image::getPostImage( null, 'large', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/9.jpg'
                                        ), 'both', null ) ?>
                                    <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                        <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'large', array(
                                                    'class' => 'img-fluid mx-auto d-block lazyload',
                                                    'data-src' => 'img/9.jpg'
                                            ), 'both', null ) ?></a>
                                    <?php endif; ?>
                                    <?php if ( is_singular() ) : ?>
                                        <h4 class="mg-md tc-black"><?php the_title(); ?></h4>
                                    <?php else : ?>
                                        <h4 class="mg-md tc-black"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h4>
                                    <?php endif; ?>
                                    <?php the_excerpt( ); ?>
                                </div>
                            <?php endif; ?>
                            <?php $item_number++; ?>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                    <?php endif; ?>
                    <?php rewind_posts(); ?>
                    <?php if ( have_posts() ) : ?>
                        <?php $item_number = 0; ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php if( $item_number == 1 ) : ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
                                    <?php if ( is_singular() ) : ?>
                                        <?php echo PG_Image::getPostImage( null, 'large', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/9.jpg'
                                        ), 'both', null ) ?>
                                    <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                        <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'large', array(
                                                    'class' => 'img-fluid mx-auto d-block lazyload',
                                                    'data-src' => 'img/9.jpg'
                                            ), 'both', null ) ?></a>
                                    <?php endif; ?>
                                    <?php if ( is_singular() ) : ?>
                                        <h4 class="mg-md tc-black"><?php the_title(); ?></h4>
                                    <?php else : ?>
                                        <h4 class="mg-md tc-black"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h4>
                                    <?php endif; ?>
                                    <?php the_excerpt( ); ?>
                                </div>
                            <?php endif; ?>
                            <?php $item_number++; ?>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                    <?php endif; ?>
                    <?php rewind_posts(); ?>
                    <?php if ( have_posts() ) : ?>
                        <?php $item_number = 0; ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php if( $item_number == 2 ) : ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
                                    <?php if ( is_singular() ) : ?>
                                        <?php echo PG_Image::getPostImage( null, 'large', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/9.jpg'
                                        ), 'both', null ) ?>
                                    <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                        <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'large', array(
                                                    'class' => 'img-fluid mx-auto d-block lazyload',
                                                    'data-src' => 'img/9.jpg'
                                            ), 'both', null ) ?></a>
                                    <?php endif; ?>
                                    <?php if ( is_singular() ) : ?>
                                        <h4 class="mg-md tc-black"><?php the_title(); ?></h4>
                                    <?php else : ?>
                                        <h4 class="mg-md tc-black"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h4>
                                    <?php endif; ?>
                                    <?php the_excerpt( ); ?>
                                </div>
                            <?php endif; ?>
                            <?php $item_number++; ?>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                    <?php endif; ?>
                    <?php rewind_posts(); ?>
                    <?php if ( have_posts() ) : ?>
                        <?php $item_number = 0; ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php if( $item_number == 3 ) : ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
                                    <?php if ( is_singular() ) : ?>
                                        <?php echo PG_Image::getPostImage( null, 'large', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/9.jpg'
                                        ), 'both', null ) ?>
                                    <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                        <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'large', array(
                                                    'class' => 'img-fluid mx-auto d-block lazyload',
                                                    'data-src' => 'img/9.jpg'
                                            ), 'both', null ) ?></a>
                                    <?php endif; ?>
                                    <?php if ( is_singular() ) : ?>
                                        <h4 class="mg-md tc-black"><?php the_title(); ?></h4>
                                    <?php else : ?>
                                        <h4 class="mg-md tc-black"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h4>
                                    <?php endif; ?>
                                    <?php the_excerpt( ); ?>
                                </div>
                            <?php endif; ?>
                            <?php $item_number++; ?>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                    <?php endif; ?>
                </div>
                <?php if ( is_active_sidebar( 'hoopsidebararchive' ) ) : ?>
                    <div class="col-lg-4 offset-lg-2">
                        <?php dynamic_sidebar( 'hoopsidebararchive' ); ?>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- bloc-2 END -->
    <!-- bloc-4 -->
    <div class="bloc l-bloc" id="bloc-4">
        <div class="container bloc-lg">
            <div class="row">
                <div class="col">
                    <div>
                        <?php if ( PG_Pagination::isPaginated() ) : ?>
                            <?php for( $page_num = 1; $page_num <= PG_Pagination::getMaxPages(); $page_num++) : ?>
                                <a href="<?php echo esc_url( get_pagenum_link( $page_num ) ) ?>" class="btn btn-yellow-orange"><?php echo $page_num ?></a>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-4 END -->
    <!-- ScrollToTop Button -->
    <a class="bloc-button btn btn-d scrollToTop" onclick="scrollToTarget('1',this)"><span class="fa fa-chevron-up"></span></a>
    <!-- ScrollToTop Button END-->
    <!-- bloc-41 -->
    <?php get_template_part( 'parts/main', 'footer' ); ?>
    <!-- bloc-41 END -->
</div>        

<?php get_footer(); ?>