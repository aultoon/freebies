<?php get_header(); ?>

<!-- Main container -->
<div class="page-container">
    <!-- bloc-0 -->
    <?php get_template_part( 'parts/main', 'header' ); ?>
    <!-- bloc-0 END -->
    <!-- bloc-1 -->
    <?php get_template_part( 'parts/main', 'slogan' ); ?>
    <!-- bloc-1 END -->
    <!-- bloc-2 -->
    <div class="bloc tc-olive-drab-7 l-bloc" id="bloc-2">
        <div class="container bloc-sm">
            <div class="row">
                <?php rewind_posts(); ?>
                <?php if ( have_posts() ) : ?>
                    <?php $item_number = 0; ?>
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php if( $item_number == 0 ) : ?>
                            <?php PG_Helper::rememberShownPost(); ?>
                            <div <?php post_class( 'col-md-6 col-lg-8' ); ?> id="post-<?php the_ID(); ?>">
                                <?php if ( is_singular() ) : ?>
                                    <?php echo PG_Image::getPostImage( null, 'full', array(
                                            'class' => 'img-fluid mx-auto d-block lazyload',
                                            'data-src' => 'img/2.jpg'
                                    ), 'both', null ) ?>
                                <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                    <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'full', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/2.jpg'
                                        ), 'both', null ) ?></a>
                                <?php endif; ?>
                                <?php if ( is_singular() ) : ?>
                                    <h3 class="mg-md tc-black"><?php the_title(); ?></h3>
                                <?php else : ?>
                                    <h3 class="mg-md tc-black"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h3>
                                <?php endif; ?>
                                <p class="p-style"><?php echo get_the_excerpt(); ?></p>
                            </div>
                        <?php endif; ?>
                        <?php $item_number++; ?>
                    <?php endwhile; ?>
                <?php else : ?>
                    <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                <?php endif; ?>
                <div class="col-md-6 col-lg-4">
                    <?php rewind_posts(); ?>
                    <?php if ( have_posts() ) : ?>
                        <?php $item_number = 0; ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php if( $item_number == 1 ) : ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
                                    <?php if ( is_singular() ) : ?>
                                        <?php echo PG_Image::getPostImage( null, 'full', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/16.jpg'
                                        ), 'both', null ) ?>
                                    <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                        <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'full', array(
                                                    'class' => 'img-fluid mx-auto d-block lazyload',
                                                    'data-src' => 'img/16.jpg'
                                            ), 'both', null ) ?></a>
                                    <?php endif; ?>
                                    <?php if ( is_singular() ) : ?>
                                        <h5 class="mg-md"><?php the_title(); ?></h5>
                                    <?php else : ?>
                                        <h5 class="mg-md"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h5>
                                    <?php endif; ?>
                                    <?php the_excerpt( ); ?>
                                </div>
                            <?php endif; ?>
                            <?php $item_number++; ?>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                    <?php endif; ?>
                    <?php rewind_posts(); ?>
                    <?php if ( have_posts() ) : ?>
                        <?php $item_number = 0; ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php if( $item_number == 2 ) : ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class(); ?> id="post-<?php the_ID(); ?>">
                                    <?php if ( is_singular() ) : ?>
                                        <?php echo PG_Image::getPostImage( null, 'full', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/16.jpg'
                                        ), 'both', null ) ?>
                                    <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                        <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'full', array(
                                                    'class' => 'img-fluid mx-auto d-block lazyload',
                                                    'data-src' => 'img/16.jpg'
                                            ), 'both', null ) ?></a>
                                    <?php endif; ?>
                                    <?php if ( is_singular() ) : ?>
                                        <h5 class="mg-md"><?php the_title(); ?></h5>
                                    <?php else : ?>
                                        <h5 class="mg-md"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h5>
                                    <?php endif; ?>
                                    <?php the_excerpt( ); ?>
                                </div>
                            <?php endif; ?>
                            <?php $item_number++; ?>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-2 END -->
    <!-- bloc-3 -->
    <div class="bloc none l-bloc" id="bloc-3">
        <div class="container bloc-lg">
            <div class="row">
                <div class="col">
                    <div>
                        <div class="row">
                            <?php rewind_posts(); ?>
                            <?php if ( have_posts() ) : ?>
                                <?php $item_number = 0; ?>
                                <?php while ( have_posts() ) : the_post(); ?>
                                    <?php if( $item_number >= 3 && $item_number <= 5 ) : ?>
                                        <?php PG_Helper::rememberShownPost(); ?>
                                        <div <?php post_class( 'offset-0 col-12 col-lg-4' ); ?> id="post-<?php the_ID(); ?>">
                                            <?php if ( is_singular() ) : ?>
                                                <?php echo PG_Image::getPostImage( null, 'full', array(
                                                        'class' => 'img-fluid mx-auto d-block lazyload',
                                                        'data-src' => 'img/9.jpg'
                                                ), 'both', null ) ?>
                                            <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                                <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'full', array(
                                                            'class' => 'img-fluid mx-auto d-block lazyload',
                                                            'data-src' => 'img/9.jpg'
                                                    ), 'both', null ) ?></a>
                                            <?php endif; ?>
                                            <?php if ( is_singular() ) : ?>
                                                <h4 class="mg-md tc-black"><?php the_title(); ?></h4>
                                            <?php else : ?>
                                                <h4 class="mg-md tc-black"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h4>
                                            <?php endif; ?>
                                            <?php the_excerpt( ); ?>
                                        </div>
                                    <?php endif; ?>
                                    <?php $item_number++; ?>
                                <?php endwhile; ?>
                            <?php else : ?>
                                <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3">
                    <?php if ( is_active_sidebar( 'hoopsidebar' ) ) : ?>
                        <?php dynamic_sidebar( 'hoopsidebar' ); ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-3 END -->
    <!-- bloc-4 -->
    <div class="bloc l-bloc" id="bloc-4">
        <div class="container bloc-sm">
            <div class="row">
                <?php rewind_posts(); ?>
                <?php if ( have_posts() ) : ?>
                    <?php $item_number = 0; ?>
                    <?php while ( have_posts() ) : the_post(); ?>
                        <?php if( $item_number >= 6 && $item_number <= 8 ) : ?>
                            <?php PG_Helper::rememberShownPost(); ?>
                            <div <?php post_class( 'col-md-4 offset-lg-0 col-lg-3' ); ?> id="post-<?php the_ID(); ?>">
                                <?php if ( is_singular() ) : ?>
                                    <?php echo PG_Image::getPostImage( null, 'full', array(
                                            'class' => 'img-fluid mx-auto d-block lazyload',
                                            'data-src' => 'img/9.jpg'
                                    ), 'both', null ) ?>
                                <?php elseif ( has_post_thumbnail( get_the_ID() ) ) : ?>
                                    <a href="<?php echo esc_url( get_permalink() ); ?>"><?php echo PG_Image::getPostImage( null, 'full', array(
                                                'class' => 'img-fluid mx-auto d-block lazyload',
                                                'data-src' => 'img/9.jpg'
                                        ), 'both', null ) ?></a>
                                <?php endif; ?>
                                <?php if ( is_singular() ) : ?>
                                    <h4 class="mg-md tc-black"><?php the_title(); ?></h4>
                                <?php else : ?>
                                    <h4 class="mg-md tc-black"><a href="<?php echo esc_url( get_permalink() ); ?>"><?php the_title(); ?></a></h4>
                                <?php endif; ?>
                                <?php the_excerpt( ); ?>
                            </div>
                        <?php endif; ?>
                        <?php $item_number++; ?>
                    <?php endwhile; ?>
                <?php else : ?>
                    <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <!-- bloc-4 END -->
    <!-- bloc-5 -->
    <div class="bloc l-bloc" id="bloc-5">
        <div class="container bloc-lg">
            <div class="row">
                <div class="col">
                    <?php if ( PG_Pagination::isPaginated() ) : ?>
                        <?php for( $page_num = 1; $page_num <= PG_Pagination::getMaxPages(); $page_num++) : ?>
                            <a href="<?php echo esc_url( get_pagenum_link( $page_num ) ) ?>" class="btn btn-yellow-orange"><?php echo $page_num ?></a>
                        <?php endfor; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    <!-- bloc-5 END -->
    <!-- ScrollToTop Button -->
    <a class="bloc-button btn btn-d scrollToTop" onclick="scrollToTarget('1',this)"><span class="fa fa-chevron-up"></span></a>
    <!-- ScrollToTop Button END-->
    <!-- bloc-41 -->
    <?php get_template_part( 'parts/main', 'footer' ); ?>
    <!-- bloc-41 END -->
</div>        

<?php get_footer(); ?>