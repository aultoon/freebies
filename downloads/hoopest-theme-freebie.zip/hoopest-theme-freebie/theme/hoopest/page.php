<?php get_header(); ?>

        <!-- Main container -->
        <div class="page-container">
            <!-- bloc-0 -->
            <?php get_template_part( 'parts/main', 'header' ); ?>
            <!-- bloc-0 END -->
            <!-- bloc-19 -->
            <div class="bloc l-bloc" id="bloc-19">
                <div class="container bloc-lg">
                    <div class="row">
                        <div class="col">
                            <h1 class="h1-style mg-sm tc-black text-lg-center text-w-80 mx-auto d-block"><?php the_title(); ?></h1>
                            <p class="text-lg-center text-center"><?php the_time( get_option( 'date_format' ) ); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-19 END -->
            <!-- bloc-20 -->
            <div class="bloc tc-olive-drab-7 l-bloc" id="bloc-20">
                <div class="container bloc-sm">
                    <div class="row">
                        <div class="col-md-6 col-lg-12">
                            <?php echo PG_Image::getPostImage( null, 'full', array(
                                    'class' => 'img-fluid mx-auto d-block img-bloc-1-style lazyload',
                                    'data-src' => 'img/2.jpg'
                            ), 'both', null ) ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-20 END -->
            <!-- bloc-21 -->
            <div class="bloc tc-black l-bloc" id="bloc-21">
                <div class="container bloc-lg">
                    <div class="row">
                        <?php if ( have_posts() ) : ?>
                            <?php while ( have_posts() ) : the_post(); ?>
                                <?php PG_Helper::rememberShownPost(); ?>
                                <div <?php post_class( 'col-lg-10 offset-lg-1' ); ?> id="post-<?php the_ID(); ?>">
                                    <?php the_content(); ?>
                                </div>
                            <?php endwhile; ?>
                        <?php else : ?>
                            <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <!-- bloc-21 END -->
            <!-- bloc-22 -->
            <div class="bloc l-bloc" id="bloc-22">
                <div class="container bloc-lg">
                    <div class="row">
                        <div class="col">
                            <div>
                                <div class="text-center">
                                    <?php $terms = get_the_terms( get_the_ID(), 'category' ) ?>
                                    <?php if( !empty( $terms ) ) : ?>
                                        <?php foreach( $terms as $term ) : ?>
                                            <a href="<?php echo esc_url( get_term_link( $term, 'category' ) ) ?>" class="btn btn-sm btn-yellow-orange-2"><?php echo $term->name; ?></a>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                    <div class="row voffset">
                                        <div class="col">
                                            <div class="text-center">
                                                <?php $terms = get_the_terms( get_the_ID(), 'post_tag' ) ?>
                                                <?php if( !empty( $terms ) ) : ?>
                                                    <?php foreach( $terms as $term ) : ?>
                                                        <a href="<?php echo esc_url( get_term_link( $term, 'post_tag' ) ) ?>" class="btn btn-sm btn-yellow-orange-2"><?php echo $term->name; ?></a>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-22 END -->
            <!-- bloc-23 -->
            <div class="bloc tc-black none l-bloc" id="bloc-23">
                <div class="container bloc-lg">
                    <div class="row">
                        <div class="col-lg-2 offset-lg-1 align-self-center">
                            <?php echo get_avatar( get_the_author_meta( 'ID' ), '100' ); ?>
                        </div>
                        <div class="align-self-center col-lg-7">
                            <h5 class="mg-md tc-black"><?php the_author_meta( 'display_name' ); ?></h5>
                            <div>
                                <?php get_template_part( 'parts/main-author-links' ); ?>
                            </div>
                            <?php the_author_meta( 'description' ); ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-23 END -->
            <!-- bloc-24 -->
            <div class="bloc none l-bloc" id="bloc-24">
                <div class="container bloc-md">
</div>
            </div>
            <!-- bloc-24 END -->
            <!-- ScrollToTop Button -->
            <a class="bloc-button btn btn-d scrollToTop" onclick="scrollToTarget('1',this)"><span class="fa fa-chevron-up"></span></a>
            <!-- ScrollToTop Button END-->
            <!-- bloc-41 -->
            <?php get_template_part( 'parts/main', 'footer' ); ?>
            <!-- bloc-41 END -->
        </div>        

<?php get_footer(); ?>