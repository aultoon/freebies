<?php get_header(); ?>

        <!-- Main container -->
        <div class="page-container">
            <!-- bloc-0 -->
            <?php get_template_part( 'parts/main', 'header' ); ?>
            <!-- bloc-0 END -->
            <!-- bloc-13 -->
            <div class="bloc l-bloc" id="bloc-13">
                <div class="container bloc-lg">
                    <div class="row">
                        <div class="col">
                            <h1 class="h1-style mg-sm tc-black text-lg-center text-w-80 mx-auto d-block"><?php the_title(); ?></h1>
                            <p class="text-lg-center text-center"><?php the_time( get_option( 'date_format' ) ); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-13 END -->
            <!-- bloc-14 -->
            <div class="bloc tc-olive-drab-7 l-bloc" id="bloc-14">
                <div class="container bloc-sm">
                    <div class="row">
                        <div class="col-md-6 col-lg-12">
                            <?php echo PG_Image::getPostImage( null, 'full', array(
                                    'class' => 'img-fluid mx-auto d-block img-bloc-1-style lazyload',
                                    'data-src' => 'img/2.jpg'
                            ), 'both', null ) ?>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-14 END -->
            <!-- bloc-15 -->
            <div class="bloc tc-black l-bloc" id="bloc-15">
                <div class="container bloc-lg">
                    <?php if ( have_posts() ) : ?>
                        <?php while ( have_posts() ) : the_post(); ?>
                            <?php PG_Helper::rememberShownPost(); ?>
                            <div <?php post_class( 'row' ); ?> id="post-<?php the_ID(); ?>">
                                <div class="offset-lg-1 col-lg-10">
                                    <?php the_content(); ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    <?php else : ?>
                        <p><?php _e( 'Sorry, no posts matched your criteria.', 'hoopest' ); ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <!-- bloc-15 END -->
            <!-- bloc-16 -->
            <div class="bloc l-bloc" id="bloc-16">
                <div class="container bloc-lg">
                    <div class="row">
                        <div class="col">
                            <div class="text-center">
                                <?php $terms = get_the_terms( get_the_ID(), 'category' ) ?>
                                <?php if( !empty( $terms ) ) : ?>
                                    <?php foreach( $terms as $term ) : ?>
                                        <a class="btn btn-yellow-orange-2 button-yellow btn-sq btn-sm" href="<?php echo esc_url( get_term_link( $term, 'category' ) ) ?>"><?php echo $term->name; ?></a>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="row voffset">
                        <div class="col">
                            <div class="text-center" id="single-cats">
                                <?php $terms = get_the_terms( get_the_ID(), 'post_tag' ) ?>
                                <?php if( !empty( $terms ) ) : ?>
                                    <?php foreach( $terms as $term ) : ?>
                                        <a class="btn btn-yellow-orange-2 button-yellow btn-sq btn-sm" href="<?php echo esc_url( get_term_link( $term, 'post_tag' ) ) ?>"><?php echo $term->name; ?></a>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-16 END -->
            <!-- bloc-16 -->
            <?php get_template_part( 'parts/main', 'authors' ); ?>
            <!-- bloc-16 END -->
            <!-- bloc-11 -->
            <div class="bloc l-bloc" id="bloc-11">
                <div class="container bloc-lg">
                    <div class="row">
                        <div class="col">
                            <h3 class="mg-md tc-black mx-auto d-block text-lg-center" id="commentstitle"><?php echo get_theme_mod( 'hoop_comment_title', __( 'Comments:', 'hoopest' ) ); ?></h3>
                            <div class="row">
                                <div class="col-lg-10 offset-lg-1">
                                    <?php comments_template(); ?>
                                    <div class="text-center">
                                        <?php paginate_comments_links(); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-11 END -->
            <!-- bloc-17 -->
            <div class="bloc none l-bloc" id="bloc-17">
                <div class="container bloc-md">
</div>
            </div>
            <!-- bloc-17 END -->
            <!-- ScrollToTop Button -->
            <a class="bloc-button btn btn-d scrollToTop" onclick="scrollToTarget('1',this)"><span class="fa fa-chevron-up"></span></a>
            <!-- ScrollToTop Button END-->
            <!-- bloc-41 -->
            <?php get_template_part( 'parts/main', 'footer' ); ?>
            <!-- bloc-41 END -->
        </div>        

<?php get_footer(); ?>