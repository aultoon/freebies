<?php get_header(); ?>

        <!-- Main container -->
        <div class="page-container">
            <!-- bloc-0 -->
            <?php get_template_part( 'parts/main', 'header' ); ?>
            <!-- bloc-0 END -->
            <!-- bloc-1 -->
            <div class="bloc tc-olive-drab-7 l-bloc" id="bloc-1">
                <div class="container bloc-sm">
                    <div class="row">
                        <div class="col">
                            <div class="row voffset-lg">
                                <div class="col-12">
                                    <div>
</div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-6 col-lg-12">
                            <h1 class="h1-style mg-sm tc-black text-lg-center text-w-80 mx-auto d-block"><?php echo get_theme_mod( 'hoop_404_htext', __( '404 Not Found.', 'hoopest' ) ); ?></h1>
                            <p class="text-lg-center"><?php echo get_theme_mod( 'hoop_404_ptext', 'The page you are looking for was moved, removed, renamed or might never existed. <br>Please try searching it!' ); ?></p>
                            <div>
                                <div class="text-center">
                                    <?php get_search_form( true ); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- bloc-1 END -->
            <!-- bloc-15 -->
            <div class="bloc tc-black none l-bloc" id="bloc-15">
                <div class="container bloc-lg">
</div>
            </div>
            <!-- bloc-15 END -->
            <!-- bloc-2 -->
            <div class="bloc none l-bloc" id="bloc-2">
                <div class="container bloc-md">
</div>
            </div>
            <!-- bloc-2 END -->
            <!-- ScrollToTop Button -->
            <a class="bloc-button btn btn-d scrollToTop" onclick="scrollToTarget('1',this)"><span class="fa fa-chevron-up"></span></a>
            <!-- ScrollToTop Button END-->
            <!-- bloc-41 -->
            <?php get_template_part( 'parts/main', 'footer' ); ?>
            <!-- bloc-41 END -->
        </div>        

<?php get_footer(); ?>